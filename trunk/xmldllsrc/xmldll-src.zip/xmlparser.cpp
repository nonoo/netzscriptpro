/* #######################################
   ## xml.dll 0.1.1
   ## mIRC XML Parser DLL
   ## written by sax - irc_x@hotmail.com
   ## �2003 sax & www.ScriptsDB.org
   ####################################### */

/* XMLParser Class implementation */

#include "xmlparser.h"

void XMLParser::parse_b() {
 if (strlen(buffer)) {
  parse(buffer);
 }
}

unsigned XMLParser::parse_f() {
 if (*file == '\0') { return 0; }
 char *d;
 
 HANDLE hf = CreateFile(file,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if (hf == INVALID_HANDLE_VALUE) { return 0; }
  
 HANDLE hm = CreateFileMapping(hf,NULL,PAGE_READONLY,0,0,NULL);
 if (hm == INVALID_HANDLE_VALUE) {
  CloseHandle(hf);
  return 0;
 }

 d = (char*)MapViewOfFile(hm,FILE_MAP_READ,0,0,0);
 parse(d);
 
 UnmapViewOfFile(d);
 CloseHandle(hm);
 CloseHandle(hf);
 return 1;
}

//////
XMLEntity XMLParser::etype(const char *z) {
 if (strncmp(z,"<!--",4) == 0) { return comment; }
 if (strnicmp(z,"<![CDATA[",9) == 0) { return cdata; }
 if (strncmp(z,"<!",2) == 0) { return def; }
 if (strnicmp(z,"<?xml",5) == 0) { return xmldecl; }
 if (strncmp(z,"<?",2) == 0) { return process; }
 if (strncmp(z,"<%",2) == 0) { return def; }
 return chardata;
}

///
char *pclf(char *z) {
 while (*z == '\n' || *z == '\r') { z++; }
 return z;
}
char *pslf(char *z) {
 while (*z == '\n' || *z == '\r' || *z == ' ' || *z == '\t') { z++; }
 return z;
}
bool isclf(const char *z) {
 return (*z == '\r' || *z == '\n') ? true : false;
}

char *XMLParser::patt(char *z) {
 unsigned i, k;
 char *t;
 char *buf = new char[STR_BUF+1];
 z = pslf(z);
 do {
  i = 0;
  while (*z != '=' && *z != '>' && *z != '\0') { 
   if (*z != '\t' && *z != ' ' && !isclf(z)) { buf[i] = *z; i++; }
   z++;
  }
  if (*z == '=') { 
   buf[i] = ' ';
   z++; i++;
   k = i;
   z = pslf(z);
   if (*z == '\'') {
    z++;
    while (*z != '\'' && *z != '\0') {
     buf[i] = *z++; i++;
     if (i > STR_BUF) {
      smsg(hdattrib,buf,node);
      i = k;
     }
    }
    if (*z != '\0') {
     buf[i] = '\0';
     smsg(hdattrib,buf,node);
    }
   }
   else if (*z == '"') {
    z++;
    while (*z != '"' && *z != '\0') { 
     buf[i] = *z++; i++;
     if (i > STR_BUF) {
      smsg(hdattrib,buf,node);
      i = k;
     }
    }
    if (*z != '\0') { 
     buf[i] = '\0';
     smsg(hdattrib,buf,node);
    }
   }
   else {
    while (*z != ' ' && *z != '\t' && *z != '>' && *z != '/' && *z != '\n' && *z != '\0') { 
     buf[i] = *z++; i++;
     if (i > STR_BUF) {
      smsg(hdattrib,buf,node);
      i = k;
     }
    }
    buf[i] = '\0';
    smsg(hdattrib,buf,node);
    if (*z == '>' || *z == '/') { z--; }
   }
   z++;     
  }
  if (*z != '\0') { z = pslf(z); }
 } while (*z != '>' && *z != '\0' && *z != '/');
 if (*z == '/') { 
  t = strrchr(path,'/');
  if (t) { *t = '\0'; }
  else { *path = '\0'; }
  smsg(hdendel,node);
  z++;
 }
 if (*z == '>') { 
  bclose = false;
 }
 delete[] buf;
 return z;
}

char *XMLParser::pnode(char *z) {
 unsigned i = 0;
 char *t;
 char *buf = new char[STR_BUF+1];
 z = pslf(z);
 if (*z == '/') { z++; bclose = true; }
 while (*z != ' ' && *z != '/' && *z != '\t' && *z != '>' && *z != '\0') { buf[i] = *z++; i++; } 
 buf[i] = '\0';
 sets(node,buf);
 if (!bclose) { 
  if (strlen(path)) { strcat(path,"/"); }
  strcat(path,buf);
  smsg(hdstartel,node);
 }
 z = pslf(z);
 switch (*z) {
  case '>' :
   if (bclose) { 
    t = strrchr(path,'/');
    if (t) { *t = '\0'; }
    else { *path = '\0'; }
    smsg(hdendel,node);
    bclose = false;
   }
   break;
  case '/' :
   z++;
   z = pslf(z);
   if (*z == '>') {
    t = strrchr(path,'/');
    if (t) { *t = '\0'; }
    else { *path = '\0'; }
    smsg(hdendel,node);
   }
   break;
  case '\0' :
   break;
  default : 
   z = patt(z);
 }
 delete[] buf;
 return z;
}
///
char *XMLParser::pcmt(char *z) {
 unsigned i = 0;
 z = pslf(z);
 char *buf = new char[STR_BUF+1];
 smsg(hdstartcmt);
 while (*z != '\0') { 
  if (*z == '>') {
   z--;
   if (*z == '-') {
    z--;
    if (*z == '-') {
     if (i > 2) {
      buf[i-2] = '\0';
      smsg(hdcmt,buf);
     }
     smsg(hdendcmt);
     return z + 2;
    }
    z++;
   }
   z++;
  }
  if (isclf(z)) {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hdcmt,buf);
   }
   z = pslf(z);
   i = 0;
  }
  else {
   buf[i] = *z++; i++;
   if (i > STR_BUF) {
    buf[i] = '\0';
    smsg(hdcmt,buf);
    i = 0;
   }
  }
 }
 if (i > 0) {
  buf[i] = '\0';
  smsg(hdcmt,buf);
  smsg(hdendcmt);
 }
 delete[] buf;
 return z;
}

char *XMLParser::pcdata(char *z) {
 unsigned i = 0;
 z = pslf(z);
 char *buf = new char[STR_BUF+1];
 smsg(hdstartcdata);
 while (*z != '\0') { 
  if (*z == '>') {
   z--;
   if (*z == ']') {
    z--;
    if (*z == ']') {
     if (i > 2) {
      buf[i-2] = '\0';
      smsg(hdcdata,buf);
     }
     smsg(hdendcdata);
     return z + 2;
    }
    z++;
   }
   z++;
  }
  if (isclf(z)) {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hdcdata,buf);
   }
   z = pslf(z);
   i = 0;
  }
  else {
   buf[i] = *z++; i++;
   if (i > STR_BUF) {
    buf[i] = '\0';
    smsg(hdcdata,buf);
    i = 0;
   }
  }
 }
 if (i > 0) {
  buf[i] = '\0';
  smsg(hdcdata,buf);
  smsg(hdendcdata);
 }
 delete[] buf;
 return z;
}
char *XMLParser::ppro(char *z) {
 unsigned i = 0;
 z = pslf(z);
 char *buf = new char[STR_BUF+1];
 smsg(hdstartpro);
 while (*z != '\0') { 
  if (*z == '>') {
   z--;
   if (*z == '?') {
    if (i > 1) {
     buf[i-1] = '\0';
     smsg(hdpro,buf);
    }
    smsg(hdendpro);
    return z + 1;
   }
   z++;
  }
  if (isclf(z)) {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hdpro,buf);
   }
   z = pslf(z);
   i = 0;
  }
  else {
   buf[i] = *z++; i++;
   if (i > STR_BUF) {
    buf[i] = '\0';
    smsg(hdpro,buf);
    i = 0;
   }
  }
 }
 if (i > 0) {
  buf[i] = '\0';
  smsg(hdpro,buf);
  smsg(hdendpro);
 }
 delete[] buf;
 return z;
}
char *XMLParser::pdef(char *z) {
 unsigned i = 0;
 z = pslf(z);
 char *buf = new char[STR_BUF+1];
 smsg(hdstartdef);
 while (*z != '\0') { 
  if (*z == '>') {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hddef,buf);
   }
   smsg(hdenddef);
   return z;
  }
  if (isclf(z)) {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hddef,buf);
   }
   z = pslf(z);
   i = 0;
  }
  else {
   buf[i] = *z++; i++;
   if (i > STR_BUF) {
    buf[i] = '\0';
    smsg(hddef,buf);
    i = 0;
   }
  }
 }
 if (i > 0) {
  buf[i] = '\0';
  smsg(hddef,buf);
  smsg(hdenddef);
 }
 delete[] buf;
 return z;
}

char *XMLParser::pdat(char *z) {
 unsigned i = 0;
 char *buf = new char[STR_BUF+1];
 smsg(hdstartchar);
 while (*z != '\0') { 
  if (*z == '<') {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hdchar,buf);
   }
   smsg(hdendchar);
   return z;
  }
  if (isclf(z)) {
   if (i > 0) {
    buf[i] = '\0';
    smsg(hdchar,buf);
   }
   z = pslf(z);
   i = 0;
  }
  else {
   buf[i] = *z++; i++;
   if (i > STR_BUF) {
    buf[i] = '\0';
    smsg(hdchar,buf);
    i = 0;
   }
  }
 }
 if (i > 0) {
  buf[i] = '\0';
  smsg(hdchar,buf);
  smsg(hdendchar);
 }
 delete[] buf;
 return z;
}

char *XMLParser::pxml(char *z) {
 unsigned i = 0;
 z = pslf(z);
 char *buf = new char[STR_BUF+1];
 while (*z != '\0') { 
  if (*z == '>') {
   z--;
   if (*z == '?') {
    smsg(hdxml,true);
    return z + 1;
   }
   z++;
  }
  z = pslf(z);
  if (xdecl == xvoid) {
   if (strnicmp("version",z,7) == 0) {
    xdecl = version;
    z += 7;
   }
   else if (strnicmp("encoding",z,8) == 0) {
    xdecl = encoding;
    z += 8;
   }
   else if (strnicmp("standalone",z,10) == 0) {
    xdecl = standbyme;
    z += 10;
   }
   else {
    while (*z != '?' && *z != '>' && *z != '\t' && *z != ' ' && *z != '\0') { z++; } 
    if (*z == '>') { z--; }
   }
  }
  if (xdecl != xvoid) {
   i = 0;
   z = pslf(z);
   if (*z == '=') { 
    z++;
    z = pslf(z);
    if (*z == '\'') {
     z++;
     while (*z != '\'' && *z != '\0') {
      buf[i] = *z++;
      if (i < STR_BUF) { i++; }
     }
    }
    else if (*z == '"') {
     z++;
     while (*z != '"' && *z != '\0') { 
      buf[i] = *z++;
      if (i < STR_BUF) { i++; }
     }
    }
    if (*z != '\0') { 
     buf[i] = '\0';
     switch (xdecl) {
      case version :
       sets(xbve,buf);
       break;
      case encoding :
       sets(xben,buf);
       break;
      case standbyme :
       xbst = strnicmp("no",buf,2) == 0 ? false : true;
     }
     xdecl = xvoid;
    }
   } 
  }
  if (*z != '\0') { z++; }
 }
 delete[] buf;
 return z;
}
//////
void XMLParser::parse(char *p) {
 p = pslf(p);
 while (*p != '\0') {
  // _MAIN_ line of the whole code !
  if (*p == '<') { // this one !
   if ((entity = etype(p)) != chardata) {
    switch (entity) {
     case cdata :
      p += 9;
      p = pcdata(p);
      break;
     case comment :
      p += 4;
      p = pcmt(p);
      break;
     case process :
      p += 2;
      p = ppro(p);
      break;
     case def :
      p += 1;
      p = pdef(p);
      break;
     case xmldecl :
      p += 1;
      p = pxml(p);
    }
   }
   else {
    p++;
    p = pnode(p);
   }
   if (*p != '\0') { p++; }
  }
  else {
   p = pslf(p);
   if (*p != '<' && *p != '\0') {
    p = pdat(p);
   }
  }
 }
}


XMLParser::XMLParser() {
 name = new char[STR_BUF];
 
 node = new char[STR_BUF];
 file = new char[STR_BUF];
 path = new char[STR_BUF];
 buffer = new char[XML_BUF];

 hdstartel = new char[STR_BUF];
 hdendel = new char[STR_BUF];
 hdattrib = new char[STR_BUF];
 hdstartchar = new char[STR_BUF];
 hdendchar = new char[STR_BUF];
 hdchar = new char[STR_BUF];
 hdstartcdata = new char[STR_BUF];
 hdendcdata = new char[STR_BUF];
 hdcdata = new char[STR_BUF];
 hdstartcmt = new char[STR_BUF];
 hdendcmt = new char[STR_BUF];
 hdcmt = new char[STR_BUF];

 hdstartdef = new char[STR_BUF];
 hdenddef = new char[STR_BUF];
 hddef = new char[STR_BUF];
 hdstartpro = new char[STR_BUF];
 hdendpro = new char[STR_BUF];
 hdpro = new char[STR_BUF];

 hdxml = new char[STR_BUF];
 xbve = new char[STR_BUF];
 xben = new char[STR_BUF];
 xdecl = xvoid;
 xbst = true;
 
 bclose = false;
 
 *name = '\0';
 *buffer = '\0';
}

XMLParser::~XMLParser() {
 delete[] name;
 
 delete[] node;
 delete[] file;
 delete[] path;
 delete[] buffer;

 delete[] hdstartel;
 delete[] hdendel;
 delete[] hdattrib;
 delete[] hdstartchar;
 delete[] hdendchar;
 delete[] hdchar;
 delete[] hdstartcdata;
 delete[] hdendcdata;
 delete[] hdcdata;
 delete[] hdstartcmt;
 delete[] hdendcmt;
 delete[] hdcmt;

 delete[] hdstartdef;
 delete[] hdenddef;
 delete[] hddef;

 delete[] hdstartpro;
 delete[] hdendpro;
 delete[] hdpro;

 delete[] hdxml;
 delete[] xbve;
 delete[] xben;
}

void XMLParser::set_hd(const XMLHandler h,const char *c) {
 switch (h) {
  case ehdstartel : sets(hdstartel,c); break;
  case ehdendel : sets(hdendel,c); break;
  case ehdattrib : sets(hdattrib,c); break;
  case ehdstartchar : sets(hdstartchar,c); break;
  case ehdendchar : sets(hdendchar,c); break;
  case ehdchar : sets(hdchar,c); break;
  case ehdstartcdata : sets(hdstartcdata,c); break;
  case ehdendcdata : sets(hdendcdata,c); break;
  case ehdcdata : sets(hdcdata,c); break;
  case ehdstartcmt : sets(hdstartcmt,c); break;
  case ehdendcmt : sets(hdendcmt,c); break;
  case ehdcmt : sets(hdcmt,c); break;
  case ehdstartdef : sets(hdstartdef,c); break;
  case ehdenddef : sets(hdenddef,c); break;
  case ehddef : sets(hddef,c); break;
  case ehdstartpro : sets(hdstartpro,c); break;
  case ehdendpro : sets(hdendpro,c); break;
  case ehdpro : sets(hdpro,c); break;
  case ehdxml : sets(hdxml,c); break;
  
  case ehdfile : sets(file,c); break;
  case ehdpath : sets(path,c); break;
  case ehdbuffer : sets(buffer,c); break;
  case ehdnode : sets(node,c); break;
 }
}

// pseudo constructor
void XMLParser::init() {
 char *c = new char;
 *c = '\0';
 *hdstartel = *c;
 *hdendel = *c;
 *hdattrib = *c;
 *hdstartchar = *c;
 *hdendchar = *c;
 *hdchar = *c;
 *hdstartcdata = *c;
 *hdendcdata = *c;
 *hdcdata = *c;
 *hdstartcmt = *c;
 *hdendcmt = *c;
 *hdcmt = *c;
 *hdstartdef = *c;
 *hdenddef = *c;
 *hddef = *c;
 *hdstartpro = *c;
 *hdendpro = *c;
 *hdpro = *c;
 *hdxml = *c;
 *xbve = *c;
 *xben = *c;

 *node = *c;
 *file = *c;
 *path = *c;
 *buffer = *c;
 
 bclose = false;
 xbst = true;
 xdecl = xvoid;
 entity = chardata;
 delete c;
}

char *XMLParser::get_hd(const XMLHandler h) {
 switch (h) {
  case ehdstartel : return hdstartel;
  case ehdendel : return hdstartel;
  case ehdattrib : return hdattrib;
  case ehdstartchar : return hdstartchar;
  case ehdendchar : return hdendchar;
  case ehdchar : return hdchar;
  case ehdstartcdata : return hdstartcdata;
  case ehdendcdata : return hdendcdata;
  case ehdcdata : return hdcdata;
  case ehdstartcmt : return hdstartcmt;
  case ehdendcmt : return hdendcmt;
  case ehdcmt : return hdcmt;
  
  case ehdstartdef : return hdstartdef;
  case ehdenddef : return hdenddef;
  case ehddef : return hddef;
  case ehdstartpro : return hdstartdef;
  case ehdendpro : return hdenddef;
  case ehdpro : return hddef;
  
  case ehdxml : return hdxml;
  
  case ehdfile : return file;
  case ehdpath : return path;
  case ehdnode : return node;
  
  default : return NULL;
 }
}
