/* #######################################
   ## xml.dll 0.1.1
   ## mIRC XML Parser DLL
   ## written by sax - irc_x@hotmail.com
   ## �2003 sax & www.ScriptsDB.org
   ####################################### */

/* main dll file - mirc/dll interface */

// macros and preprocessor stuffs
#include "xmlparser.h"

#define stc(s) extern "C" int __stdcall WINAPI s(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
#define sdm SendMessage(MIRC,WM_USER + 200,0,0);

#define DLL_VERSION "0.1.1"
#define DLL_INFO "xml.dll " DLL_VERSION " - mIRC XML Parser DLL - �2003 sax & www.ScriptsDB.org"

#define retk lstrcpy(data,"S_OK"); return 3;
#define retr(s) lstrcpy(data,"E_"s); return 3;
#define rets(s) lstrcpy(data,s); return 3;

#define setok(s,c,t) *s = '\0'; lstrcpy(s,strtok(c,t));

#define EINV_PRM "INVALID_PARAMETERS"
#define EINV_PSR "INVALID_PARSER"
#define EINV_FIL "INVALID_FILE"
#define EOUT_MEM "OUT_OF_MEMORY"
#define ETOO_PSR "TOO_MANY_PARSERS_ALLOCATED"

#define xinit XMLParser *psr = parser;

// main pointer to XMLParser objects
XMLParser *parser;

// mirc 
HANDLE hFileMap;
LPSTR mData;
HWND MIRC;
typedef struct {
 DWORD mVersion;
 HWND mHwnd;
 BOOL mKeep;
} LOADINFO;

extern "C" void __stdcall LoadDll(LOADINFO* load) {
 hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,PAGE_READWRITE,0,4096,"mIRC");     
 mData = (LPSTR)MapViewOfFile(hFileMap,FILE_MAP_ALL_ACCESS,0,0,0);
 MIRC = load->mHwnd;
 parser = new XMLParser[PSR_NUM];
}
extern "C" int __stdcall UnloadDll(int t) {
 if (!t) {
  UnmapViewOfFile(mData); CloseHandle(hFileMap);
  delete [] parser;
  return 1;
 }
 else { return 0; }
}

//
void XMLParser::smsg(const char *h,const char *c,const char *d) {
 if (*h != '\0') {
  wsprintf(mData,"/%s %s %s %s",h,name,d,c);
  sdm;
 }
}
void XMLParser::smsg(const char *h,const char *c) {
 if (*h != '\0') {
  wsprintf(mData,"/%s %s %s",h,name,c);
  sdm;
 }
}
void XMLParser::smsg(const char *h) {
 if (*h != '\0') {
  wsprintf(mData,"/%s %s",h,name);
  sdm;
 }
}
void XMLParser::smsg(const char *h,bool b) {
 if (*h != '\0') {
  if (*xbve == '\0') { sets(xbve,"1.0"); }
  if (*xben == '\0') { sets(xben,"UTF-8"); }
  wsprintf(mData,"/%s %s %s %s %d",h,name,xbve,xben,xbst?1:0);
  sdm;
 }
}

XMLParser *palloc(XMLParser *p) {
 unsigned i = 0;
 while (i < PSR_NUM) {
  if (p->name[0] == '\0') { break; }
  p++; i++;
 }
 if (i < PSR_NUM) { return p; }
 return NULL;
}

XMLParser *pfind(XMLParser *p,const char *c) {
 unsigned i = 0;
 while (i < PSR_NUM) {
  if (stricmp(p->name,c) == 0) { break; }
  p++; i++;
 }
 if (i < PSR_NUM) { return p; }
 return NULL;
}

unsigned hd_set(const XMLHandler h,char *c) {
 xinit;
 char *n = new char[STR_BUF];
 char *v = new char[STR_BUF];
 setok(n,c," ");
 setok(v,NULL,"\0");
 if (*n == '\0') { 
  delete[] n; delete[] v;
  return 0;
 }
 if (!(psr = pfind(psr,n))) { 
  delete[] n; delete[] v;
  return 1;
 }
 psr->set_hd(h,v);
 delete[] n; delete[] v;
 return 2;
}
unsigned hd_get(const XMLHandler h,char *c) {
 xinit;
 char *n = new char[STR_BUF];
 setok(n,c," ");
 if (*n == '\0') { 
  delete[] n;
  return 0;
 }
 if (!(psr = pfind(psr,n))) { 
  delete[] n;
  return 1;
 }
 sets(c,psr->get_hd(h));
 delete[] n;
 return 2;
}

//
stc(p_f) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 if (!psr->parse_f()) { 
  delete[] n;
  retr(EINV_FIL);
 }
 delete[] n;
 retk;
}

stc(s_f) {
 xinit;
 char *n = new char[STR_BUF];
 char *v = new char[STR_BUF];
 if (!v) { delete[] n; retr(EOUT_MEM); }
 setok(n,data," ");
 setok(v,NULL,"\"\0");
 if (*n == '\0') { 
  delete[] n; delete[] v;
  retr(EINV_PRM); }
 if (!(psr = pfind(psr,n))) {
  delete[] n; delete[] v;
  retr(EINV_PSR);
 }
 psr->set_hd(ehdfile,v);
 delete[] n; delete[] v;
 retk;
}
//
stc(p_b) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 psr->parse_b();
 delete[] n;
 retk;
}

stc(s_b) {
 xinit;
 char *n = new char[STR_BUF];
 char *v = new char[STR_BUF];
 if (!v) { retr(EOUT_MEM); }
 setok(n,data," ");
 setok(v,NULL,"\0");
 if (*n == '\0') { 
  delete[] n; delete[] v;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n; delete[] v;
  retr(EINV_PSR);
 }
 if ((strlen(psr->buffer) + strlen(v)) > XML_BUF) {
  delete[] n; delete[] v;
  retr(EOUT_MEM);
 }
 lstrcat(psr->buffer,v);
 delete[] n; delete[] v;
 retk;
}
stc(g_bl) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 wsprintf(data,"%d",strlen(psr->buffer));
 delete[] n;
 return 3;
}
stc(f_b) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 sets(psr->buffer,"\0");
 delete[] n;
 retk;
}

int atoi(char *p) { // thx Necroman
	int r = 0;
	while (*p >= '0' && *p <= '9') { r *= 10; r += (*p++ - '0'); }
	return r;
}

stc(g_b) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 char *a = new char[STR_BUF];
 char *e = new char[STR_BUF];
 char *buf = new char[XML_BUF];
 if (!buf) { retr(EOUT_MEM); }
 unsigned k, l, b, i = 0;
 if ((b = strlen(psr->buffer))) {
  setok(a,NULL," ");
  setok(e,NULL," ");
  k = atoi(((*a == '\0') ? "0" : a));
  l = atoi(((*e == '\0') ? "850" : e)); 
  if (k < 0 || k > XML_BUF) { k = 0; }
  if ((k + l) > b) { l = (b - k) % STR_BUF; }
  for (i = 0;i < l;i++) { buf[i] = psr->buffer[k+i]; }
 }
 buf[i] = '\0';
 sets(data,buf);
 delete[] e; delete[] a; delete[] n;
 delete[] buf;
 return 3;
}

//
stc(c_psr) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if ((psr = pfind(psr,n))) {
  psr->init();
  delete[] n;
  retk;
 }
 psr = parser;
 if (!(psr = palloc(psr))) {
  delete[] n;
  retr(EOUT_MEM);
 }
 sets(psr->name,n);
 psr->init();
 delete[] n;
 retk;
}
stc(f_psr) {
 xinit;
 char *n = new char[STR_BUF];
 if (!n) { retr(EOUT_MEM); }
 setok(n,data," ");
 if (*n == '\0') { 
  delete[] n;
  retr(EINV_PRM);
 }
 if (!(psr = pfind(psr,n))) {
  delete[] n;
  retr(EINV_PSR);
 }
 sets(psr->name,"\0");
 psr->init();
 delete[] n;
 retk;
}

// set_ and get_ shits !
stc(s_hd_stel) {
 switch (hd_set(ehdstartel,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_enel) {
 switch (hd_set(ehdendel,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_att) {
 switch (hd_set(ehdattrib,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_stcha) {
 switch (hd_set(ehdstartchar,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_encha) {
 switch (hd_set(ehdendchar,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_cha) {
 switch (hd_set(ehdchar,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_stcda) {
 switch (hd_set(ehdstartcdata,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_encda) {
 switch (hd_set(ehdendcdata,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_cda) {
 switch (hd_set(ehdcdata,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_stcmt) {
 switch (hd_set(ehdstartcmt,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_encmt) {
 switch (hd_set(ehdendcmt,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_cmt) {
 switch (hd_set(ehdcmt,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}

stc(s_hd_stdef) {
 switch (hd_set(ehdstartdef,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_endef) {
 switch (hd_set(ehdenddef,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_def) {
 switch (hd_set(ehddef,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_stpro) {
 switch (hd_set(ehdstartpro,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_enpro) {
 switch (hd_set(ehdendpro,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_pro) {
 switch (hd_set(ehdpro,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
stc(s_hd_xml) {
 switch (hd_set(ehdxml,data)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : retk;
 }
}
//
stc(g_hd_cmt) {
 char *c = data;
 switch (hd_get(ehdcmt,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stcmt) {
 char *c = data;
 switch (hd_get(ehdstartcmt,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_encmt) {
 char *c = data;
 switch (hd_get(ehdendcmt,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stel) {
 char *c = data;
 switch (hd_get(ehdstartel,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_enel) {
 char *c = data;
 switch (hd_get(ehdendel,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_att) {
 char *c = data;
 switch (hd_get(ehdattrib,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stcha) {
 char *c = data;
 switch (hd_get(ehdstartchar,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_encha) {
 char *c = data;
 switch (hd_get(ehdendchar,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_cha) {
 char *c = data;
 switch (hd_get(ehdchar,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stcda) {
 char *c = data;
 switch (hd_get(ehdstartcdata,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_encda) {
 char *c = data;
 switch (hd_get(ehdendcdata,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_cda) {
 char *c = data;
 switch (hd_get(ehdcdata,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stdef) {
 char *c = data;
 switch (hd_get(ehdstartdef,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_endef) {
 char *c = data;
 switch (hd_get(ehdenddef,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_def) {
 char *c = data;
 switch (hd_get(ehddef,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_stpro) {
 char *c = data;
 switch (hd_get(ehdstartpro,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_enpro) {
 char *c = data;
 switch (hd_get(ehdendpro,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_pro) {
 char *c = data;
 switch (hd_get(ehdpro,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
stc(g_hd_xml) {
 char *c = data;
 switch (hd_get(ehdxml,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}
//
stc(g_f) {
 char *c = data;
 switch (hd_get(ehdfile,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}

stc(g_p) {
 char *c = data;
 switch (hd_get(ehdpath,c)) {
  case 0 : retr(EINV_PRM);
  case 1 : retr(EINV_PSR);
  default : rets(c);
 }
}

//
stc(g_ver) { rets(DLL_VERSION); }
stc(g_inf) { rets(DLL_INFO); }
