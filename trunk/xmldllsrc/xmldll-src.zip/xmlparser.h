/* #######################################
   ## xml.dll 0.1.1
   ## mIRC XML Parser DLL
   ## written by sax - irc_x@hotmail.com
   ## �2003 sax & www.ScriptsDB.org
   ####################################### */

/* XMLParser Class header file */

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define PSR_NUM 0xff
#define STR_BUF 0x35c // mirc limitation
#define XML_BUF 0xfff
#define sets(s,c) lstrcpy(s,c);

// enumerators
enum XMLDecl {
 xvoid,
 version,
 encoding,
 standbyme // =]
};

enum XMLEntity {
 chardata,
 element,
 attribute,
 cdata,
 process,
 comment,
 xmldecl,
 def
};

enum XMLHandler {
 ehdstartel,
 ehdendel,
 ehdattrib,
 ehdstartchar,
 ehdendchar,
 ehdchar,
 ehdstartcdata,
 ehdendcdata,
 ehdcdata,
 ehdstartcmt,
 ehdendcmt,
 ehdcmt,

 ehdstartdef,
 ehdenddef,
 ehddef,
 ehdstartpro,
 ehdendpro,
 ehdpro,
 
 ehdxml,
 
 ehdnode,
 ehdbuffer,
 ehdfile,
 ehdpath

};

// parsers objects, methods and properties are encapsulated in this class 
class XMLParser {
 public:
  XMLParser();
  ~XMLParser();
 
  void init();
  void set_hd(const XMLHandler h,const char *c);
  char *get_hd(const XMLHandler h);
 
  unsigned parse_f();
  void parse_b();
  
  char *name;
  char *buffer;

  XMLParser *palloc(XMLParser *p);
  XMLParser *pfind(XMLParser *p,const char *c);

 private:
  XMLEntity entity;
  XMLEntity etype(const char *z);

  XMLDecl xdecl;

  void parse(char *p);

  void smsg(const char *h,const char *c);
  void smsg(const char *h,const char *c,const char *d);
  void smsg(const char *h,bool b);
  void smsg(const char *h);

  char *pcmt(char *c);
  char *pcdata(char *c);
  char *pdef(char *c);
  char *ppro(char *c);
  char *pnode(char *c);
  char *patt(char *c);
  char *pdat(char *c);
  char *pxml(char *c);

  bool bclose;

  char *node;
  char *file;
  char *path;

  char *hdstartel;
  char *hdendel;
  char *hdattrib;
  char *hdstartchar;
  char *hdendchar;
  char *hdchar;
  char *hdstartcdata;
  char *hdendcdata;
  char *hdcdata;
  char *hdstartcmt;
  char *hdendcmt;
  char *hdcmt;

  char *hdstartdef;
  char *hdenddef;
  char *hddef;
  char *hdstartpro;
  char *hdendpro;
  char *hdpro;

  char *hdxml;
  char *xben;
  char *xbve;
  bool xbst;

};

// miscs prototypes
unsigned hd_set(const XMLHandler h,char *c);
unsigned hd_get(const XMLHandler h,char *c);

